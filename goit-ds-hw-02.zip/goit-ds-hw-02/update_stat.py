
import sqlite3

def update_task_status(task_id, new_status_id):
        with sqlite3.connect('tables.db') as conn:
            cur = conn.cursor()
            cur.execute("UPDATE tasks SET status_id = ? WHERE id = ?", (new_status_id, task_id))
        conn.commit()

task_id_to_update = 2  
new_status_id = 3  
update_task_status(task_id_to_update, new_status_id)

