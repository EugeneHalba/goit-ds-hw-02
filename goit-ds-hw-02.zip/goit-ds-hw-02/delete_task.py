import sqlite3

def delete_task(task_id):
    
    with sqlite3.connect('tables.db') as conn:
        cursor = conn.cursor()  
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        conn.commit()  
        print(f"Task with id {task_id} deleted successfully.")

task_id = 21 
delete_task(task_id)