import sqlite3

def find_email(user_email):
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        cur.execute ("SELECT * FROM users WHERE email LIKE ?", (user_email,))
        return cur.fetchall()

res = find_email('lesterkatie@example.net')
for mail in res:
    print (mail)