import sqlite3

def find_user_without_description(description):
    with sqlite3.connect('tables.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tasks WHERE description IS NUL OR description != ?", (description,))
        tasks = cursor.fetchall()
        return tasks
description_to_search = ''
tasks = find_user_without_description(description_to_search)
for task in tasks:
    print (task)

