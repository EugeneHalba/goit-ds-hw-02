import sqlite3

def update_user(fullname,new_username):
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        cur.execute ('UPDATE users SET fullname = ? WHERE fullname = ? ',(new_username, fullname ))
        conn.commit()

update_user('Patricia Perkins', 'user_1')