from faker import Faker
from random import randint
import sqlite3

# Initialize the Faker generator
fake = Faker()

# Constants for the number of records to generate
NUMBER_USERS = 20
NUMBER_TASKS = 20

# Function to generate fake data
def generate_fake_data(number_users, number_tasks):
    fake_users = [(fake.name(), fake.unique.email()) for _ in range(number_users)]
    fake_status = [('new',), ('in progress',), ('completed',)]
    fake_tasks = [
        (
            fake.sentence(nb_words=5),
            fake.text(max_nb_chars=200),
            randint(1, len(fake_status)),
            randint(1, number_users)
        ) for _ in range(number_tasks)
    ]
    return fake_users, fake_status, fake_tasks

# Function to insert data into the database
def insert_data_to_db(users, status, tasks):
    try:
        with sqlite3.connect('tables.db') as con:
            cur = con.cursor()

            # Create tables
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fullname TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    status_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    FOREIGN KEY (status_id) REFERENCES status (id),
                    FOREIGN KEY (user_id) REFERENCES users (id)
                );
            """)

            # Insert users
            cur.executemany("INSERT INTO users(fullname, email) VALUES (?, ?)", users)

            # Insert statuses
            cur.executemany("INSERT INTO status(name) VALUES (?)", status)

            # Insert tasks
            cur.executemany("INSERT INTO tasks(title, description, status_id, user_id) VALUES (?, ?, ?, ?)", tasks)

            con.commit()
    except sqlite3.Error as e:
        print(f"An error occurred: {e.args[0]}")

# Main execution
if __name__ == "__main__":
    users, status, tasks = generate_fake_data(NUMBER_USERS, NUMBER_TASKS)
    insert_data_to_db(users, status, tasks)
    print("Fake data has been inserted into the database.")