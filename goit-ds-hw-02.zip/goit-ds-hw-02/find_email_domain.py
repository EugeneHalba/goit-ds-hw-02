import sqlite3

def get_tasks_by_email_domain(domain):
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        query = '''
            SELECT tasks.id, tasks.description, tasks.status_id, users.email
            FROM tasks
            JOIN users ON tasks.user_id = users.id
            WHERE users.email LIKE ?
        '''
        cur.execute(query, ('%' + domain,))
        results = cur.fetchall()
        for row in results:
            print(f"Description: {row[1]}, User Email: {row[3]}")


get_tasks_by_email_domain('example.com') 