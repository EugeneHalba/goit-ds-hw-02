import sqlite3

def get_users_and_tasks_in_progress():
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        query = '''
            SELECT users.id, fullname, tasks.description
            FROM users
            INNER JOIN tasks ON users.id = tasks.user_id
            INNER JOIN status ON tasks.status_id = status.id
            WHERE status.name = 'in progress'
        '''
        cur.execute(query)
        results = cur.fetchall()
        for row in results:
            print(f" User: {row[1]}, Description with status in progress : {row[2]}", )


get_users_and_tasks_in_progress()