import sqlite3

def add_new_description(user_id, title, status_id, description):
    with sqlite3.connect('tables.db') as conn:
        cursor = conn.cursor()
        cursor.execute ("INSERT INTO tasks (user_id, title, status_id, description) VALUES(?, ?, ?, ?)",(user_id, title, status_id, description))
        conn.commit ()
user_id = 1
description = "hello world"
title = "say, hello"
status_id = 1
add_new_description (user_id, title, status_id, description)
print('title inserted')
