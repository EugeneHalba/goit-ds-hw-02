import sqlite3

def find_user_without_title():
    with sqlite3.connect('tables.db') as conn:
        cursor = conn.cursor() 
        cursor.execute("""SELECT * FROM users WHERE id NOT IN (SELECT user_id FROM tasks)""")
        tasks = cursor.fetchall()
        return tasks

tasks = find_user_without_title()
for empty in tasks:
    print (f"Users without title :{empty}")

