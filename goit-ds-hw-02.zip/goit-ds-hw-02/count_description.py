import sqlite3

def count_description ():
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        cur.execute('SELECT status_id, COUNT(*) FROM tasks GROUP BY status_id')
        results = cur.fetchall()

        for row in results:
            print(f"Status: {row[0]}, Task Count: {row[1]}") 
count_description ()

    