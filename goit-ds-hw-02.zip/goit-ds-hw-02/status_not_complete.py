import sqlite3

def get_incomplete_tasks():
    with sqlite3.connect('tables.db') as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, user_id, title, description, status_id
            FROM tasks
            WHERE status_id != (SELECT id FROM status WHERE name = 'completed')
        """)
        incomplete_tasks = cur.fetchall()
        return incomplete_tasks

incomplete_tasks = get_incomplete_tasks()
for task in incomplete_tasks:
    print(incomplete_tasks)