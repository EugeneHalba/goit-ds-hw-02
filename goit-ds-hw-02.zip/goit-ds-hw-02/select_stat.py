import sqlite3

def get_tasks_by_user(status_id):
        with sqlite3.connect('tables.db') as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM tasks WHERE status_id = ?", (status_id,))
            tasks = cur.fetchall()
        return tasks

user_id_to_search = 1 
tasks = get_tasks_by_user(user_id_to_search)
for task in tasks:
    print(task)