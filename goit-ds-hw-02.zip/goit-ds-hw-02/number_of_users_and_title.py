import sqlite3

def count_users ():
    with sqlite3.connect ('tables.db') as conn:
        cur = conn.cursor ()
        users = ''' 
            SELECT fullname, users.email, COUNT(tasks.id) AS task_count 
            FROM users
            LEFT JOIN tasks ON users.id = tasks.user_id
            GROUP BY users.id, users.email;

        '''
        cur.execute (users)
        result = cur.fetchall()
        for row in result:
            print (f"User: {row[0]}, Task : {row[2]}")

count_users ()

